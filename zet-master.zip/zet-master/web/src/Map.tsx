import { useEffect, useRef, useState } from "react";
import * as maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import {
  BigStaticData,
  CompressedBigStaticData,
  Vehicle,
  CompressedRealTimeState,
  decompressRealTimeState,
  RealTimeState,
  decompressBigStaticData,
  SmallStaticData,
  decompressSmallStaticData,
  CompressedSmallStaticData,
  RouteId,
} from "./Data";
import {
  FilterControl,
  FilterOverlay,
  useFilterState,
  FilterState,
} from "./Filter";
import { InfoControl, InfoOverlay } from "./Info";
import { MarkerManager, MarkerProperties } from "./Markers";
import "./Map.css";

// Helper function to get URLs dynamically based on protocol
function getUrl(schema: string, secureSchema: string, path: string) {
  return window.location.protocol === "https:"
    ? `${secureSchema}://${window.location.host}/${path}` // Use wss for HTTPS
    : `${schema}://${window.location.hostname}:5000/${path}`; // Use ws for HTTP
}

interface LoadedBigStaticData {
  key: string;
  data: BigStaticData;
}

interface LoadedSmallStaticData {
  key: string;
  data: SmallStaticData;
}

// This class helps in selecting and highlighting a vehicle by its RouteId
class HighlightedVehicleCriterion {
  private routeId: RouteId | null = null;

  setSelectedRouteId(routeId: RouteId | null) {
    this.routeId = routeId;
  }

  isHighlighted(vehicle: Vehicle): boolean {
    return this.routeId != null && vehicle.routeId === this.routeId;
  }
}

// Function to update markers on the map
function updateMarkers(
  map: maplibregl.Map,
  vehicles: Vehicle[],
  markerManager: MarkerManager,
  highlightedVehicleCriterion: HighlightedVehicleCriterion,
  filterSelection: Set<RouteId>
): boolean {
  const source = map.getSource("vehicle-markers") as maplibregl.GeoJSONSource;
  const highlightedSource = map.getSource(
    "highlighted-vehicle-markers"
  ) as maplibregl.GeoJSONSource;
  const features: GeoJSON.Feature[] = [];
  const highlightedFeatures: GeoJSON.Feature[] = [];

  vehicles.forEach((vehicle) => {
    const coord: [number, number] = [
      vehicle.lon[vehicle.lon.length - 1],
      vehicle.lat[vehicle.lat.length - 1],
    ];

    let deg;
    if (vehicle.directionDegrees != null) {
      deg = Math.round(vehicle.directionDegrees / 12) * 12;
    } else {
      deg = null;
    }
    const highlighted = highlightedVehicleCriterion.isHighlighted(vehicle);
    const hidden =
      filterSelection.size > 0 && !filterSelection.has(vehicle.routeId);
    if (hidden && !highlighted) {
      return;
    }
    const markerProperties: MarkerProperties = {
      label: vehicle.routeId.toString(),
      directionDegrees: deg,
      highlighted: false,
    };

    const marker = markerManager.getOrCreate(map, markerProperties);
    const feature: GeoJSON.Feature = {
      type: "Feature",
      geometry: {
        type: "Point",
        coordinates: coord,
      },
      properties: {
        markerKey: marker.key,
        shapeId: vehicle.shapeId,
        routeId: vehicle.routeId,
        zOrder: -vehicle.routeId,
      },
    };
    features.push(feature);
    if (highlighted) {
      const highlightedMarkerProperties: MarkerProperties = {
        ...markerProperties,
        highlighted: true,
      };
      const highlightedMarker = markerManager.getOrCreate(
        map,
        highlightedMarkerProperties
      );
      const highlightedFeature: GeoJSON.Feature = {
        ...feature,
        properties: {
          ...feature.properties,
          markerKey: highlightedMarker.key,
        },
      };
      highlightedFeatures.push(highlightedFeature);
    }
  });

  source.setData({
    type: "FeatureCollection",
    features: features,
  });
  highlightedSource.setData({
    type: "FeatureCollection",
    features: highlightedFeatures,
  });

  const anyMarkerVisible =
    features.length > 0 || highlightedFeatures.length > 0;
  return anyMarkerVisible;
}

// Function to update vehicle trajectories
function updateTrajectories(
  map: maplibregl.Map,
  vehicles: Vehicle[],
  filterSelection: Set<RouteId>
) {
  const features: GeoJSON.Feature[] = [];
  for (const vehicle of vehicles) {
    if (filterSelection.size > 0 && !filterSelection.has(vehicle.routeId)) {
      continue;
    }
    features.push({
      type: "Feature",
      geometry: {
        type: "LineString",
        coordinates: vehicle.lon.map((lon, index) => [lon, vehicle.lat[index]]),
      },
      properties: {
        routeId: vehicle.routeId,
      },
    });
  }

  const source = map.getSource("trajectories") as maplibregl.GeoJSONSource;
  source.setData({
    type: "FeatureCollection",
    features: features,
  });
}

// Fetch big static data from the server
async function fetchBigStaticData(key: string) {
  const url = getUrl("http", "https", `static/${key}`);
  const response = await fetch(url);
  const compressedData: CompressedBigStaticData = await response.json();
  return decompressBigStaticData(compressedData);
}

// Fetch small static data from the server
async function fetchSmallStaticData(key: string) {
  const url = getUrl("http", "https", `static/small/v0/${key}`);
  const response = await fetch(url);
  const compressedData: CompressedSmallStaticData = await response.json();
  return decompressSmallStaticData(compressedData);
}

// Update selected shape when clicked
async function updateSelectedShape(
  map: maplibregl.Map,
  selectedShapeId: string | null,
  loadedBigStaticData: LoadedBigStaticData | null,
  activeStaticKey: string,
  setLoadedBigStaticData: (data: LoadedBigStaticData) => void
) {
  const source = map.getSource("selected-shape") as maplibregl.GeoJSONSource;

  if (selectedShapeId == null) {
    source.setData({
      type: "FeatureCollection",
      features: [],
    });
    return null;
  }
  let bigStaticData: BigStaticData;
  if (
    loadedBigStaticData == null ||
    loadedBigStaticData.key !== activeStaticKey
  ) {
    bigStaticData = await fetchBigStaticData(activeStaticKey);
    setLoadedBigStaticData({ key: activeStaticKey, data: bigStaticData });
  } else {
    bigStaticData = loadedBigStaticData.data;
  }
  const shape = bigStaticData.shapes[selectedShapeId];
  let features: GeoJSON.Feature[] = [];
  if (shape != null) {
    features = [
      {
        type: "Feature",
        geometry: {
          type: "LineString",
          coordinates: shape.lons.map((lon, index) => [lon, shape.lats[index]]),
        },
        properties: {},
      },
    ];
  }
  source.setData({ type: "FeatureCollection", features: features });
}

// Initialize the map and set up layers, sources, and interactions
export function Map() {
  const mapContainer = useRef<HTMLDivElement>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const [mapLoaded, setMapLoaded] = useState<boolean>(false);
  const [showInfo, setShowInfo] = useState<boolean>(false);
  const [showFilter, setShowFilter] = useState<boolean>(false);

  const [filterState, setFilterState] = useFilterState("zet-filter-state", {
    selection: new Set(),
    enabled: false,
  });
  const filterStateRef = useRef<FilterState>(filterState);
  const anyMarkerVisibleRef = useRef<boolean>(true);

  const markerManager = useRef<MarkerManager>(new MarkerManager());
  const [selectedShapeId, setSelectedShapeId] = useState<string | null>(null);
  const [activeStaticKey, setActiveStaticKey] = useState<string | null>(null);
  const [loadedBigStaticData, setLoadedBigStaticData] =
    useState<LoadedBigStaticData | null>(null);
  const [loadedSmallStaticData, setLoadedSmallStaticData] =
    useState<LoadedSmallStaticData | null>(null);
  const realTimeData = useRef<RealTimeState | null>(null);
  const highlightedVehicleCriterion = useRef<HighlightedVehicleCriterion>(new HighlightedVehicleCriterion());
  const filterControlRef = useRef<FilterControl | null>(null);

  const redraw = () => {
    if (
      mapRef.current == null ||
      realTimeData.current == null ||
      filterControlRef.current == null
    ) {
      return;
    }
    const activeSelection = filterStateRef.current.enabled
      ? filterStateRef.current.selection
      : new Set<RouteId>();

    anyMarkerVisibleRef.current = updateMarkers(
      mapRef.current,
      realTimeData.current.vehicles,
      markerManager.current,
      highlightedVehicleCriterion.current,
      activeSelection
    );
    if (filterControlRef.current != null) {
      filterControlRef.current.updateState(
        filterStateRef.current,
        anyMarkerVisibleRef.current
      );
    }
    updateTrajectories(
      mapRef.current,
      realTimeData.current.vehicles,
      activeSelection
    );
  };

  // Initialize map
  useEffect(() => {
    if (!mapContainer.current) {
      return;
    }

    const center: [number, number] = [15.9819, 45.815];
    const map = (mapRef.current = new maplibregl.Map({
      container: mapContainer.current,
      style: "/style.json", // Load the map style from a static JSON file
      center: center,
      zoom: 12,
      minZoom: 9,
      maxZoom: 18,
      maxBounds: [
        [center[0] - 0.5, center[1] - 0.27],
        [center[0] + 0.5, center[1] + 0.22],
      ],
      dragRotate: false,
      pitchWithRotate: false,
      rollEnabled: false,
      boxZoom: false,
    }));
    map.touchZoomRotate.disableRotation();

    map.addControl(
      new maplibregl.GeolocateControl({
        positionOptions: {
          enableHighAccuracy: true,
        },
        trackUserLocation: true,
      })
    );

    map.addControl(new InfoControl(() => setShowInfo(true)));
    filterControlRef.current = new FilterControl({
      onShowFilter: () => setShowFilter(true),
      onToggleFilter: (enabled: boolean) => {
        const newFilterState = { ...filterStateRef.current, enabled };
        setFilterState(newFilterState);
        filterStateRef.current = newFilterState;
        redraw();
      },
      initialState: filterStateRef.current,
    });
    map.addControl(filterControlRef.current, "bottom-right");

    map.on("load", () => {
      if (!map) return;

      const emptyGeoJSON: maplibregl.GeoJSONSourceSpecification = {
        type: "geojson",
        data: {
          type: "FeatureCollection",
          features: [],
        },
      };

      map.addSource("vehicle-markers", emptyGeoJSON);
      map.addSource("highlighted-vehicle-markers", emptyGeoJSON);
      map.addSource("trajectories", emptyGeoJSON);
      map.addSource("selected-shape", emptyGeoJSON);

      map.addLayer({
        id: "trajectory-lines",
        type: "line",
        source: "trajectories",
        paint: {
          "line-color": "#ff6464",
          "line-opacity": 0.7,
          "line-width": 2,
        },
      });

      map.addLayer({
        id: "vehicle-markers",
        type: "symbol",
        source: "vehicle-markers",
        layout: {
          "icon-image": ["get", "markerKey"],
          "icon-size": 1,
          "icon-allow-overlap": true,
          "symbol-sort-key": ["get", "zOrder"],
        },
      });

      map.setPaintProperty("vehicle-markers", "icon-opacity", 1.0);

      map.addLayer({
        id: "selected-shape",
        type: "line",
        source: "selected-shape",
        paint: {
          "line-color": "#000",
          "line-width": 3,
        },
      });

      map.addLayer({
        id: "highlighted-vehicle-markers",
        type: "symbol",
        source: "highlighted-vehicle-markers",
        layout: {
          "icon-image": ["get", "markerKey"],
          "icon-size": 1,
          "icon-allow-overlap": true,
          "symbol-sort-key": ["get", "zOrder"],
        },
      });

      map.on("click", (e) => {
        const features = map.queryRenderedFeatures(e.point, {
          layers: ["highlighted-vehicle-markers", "vehicle-markers"],
        });
        const feature = findSelectedMarkerFeature(
          map,
          markerManager.current,
          features,
          e.point
        );
        if (feature != null) {
          setSelectedShapeId(feature.properties?.shapeId);
          highlightedVehicleCriterion.current.setSelectedRouteId(
            feature.properties?.routeId
          );
        } else {
          setSelectedShapeId(null);
          highlightedVehicleCriterion.current.setSelectedRouteId(null);
        }
        if (realTimeData.current != null) {
          redraw();
        }
      });

      map.on("mouseenter", "vehicle-markers", () => {
        map.getCanvas().style.cursor = "pointer";
      });

      map.on("mouseleave", "vehicle-markers", () => {
        map.getCanvas().style.cursor = "";
      });

      setMapLoaded(true);
    });

    return () => {
      map.remove();
    };
  }, []);

  return (
    <>
      <div ref={mapContainer} style={{ width: "100%", height: "100%" }} />
      {showInfo && <InfoOverlay onClose={() => setShowInfo(false)} />}
      {showFilter && (
        <FilterOverlay
          onClose={() => setShowFilter(false)}
          smallStaticData={loadedSmallStaticData?.data}
          selection={filterState.selection}
          onSelectionChange={(newSelection) => {
            const newFilterState = {
              selection: newSelection,
              enabled: filterStateRef.current.enabled || newSelection.size > 0,
            };
            setFilterState(newFilterState);
            filterStateRef.current = newFilterState;
            redraw();
          }}
        />
      )}
    </>
  );
}
