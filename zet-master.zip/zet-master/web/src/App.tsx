import { Map } from './Map';

function App() {
  return (
    <Map />
  );
}

export default App;
