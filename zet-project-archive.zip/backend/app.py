from flask import Flask, send_from_directory
from flask_socketio import SocketIO, send

app = Flask(__name__)
socketio = SocketIO(app)

@app.route('/style.json')
def serve_style():
    return send_from_directory('static', 'style.json')

@socketio.on('connect')
def handle_connect():
    print('Client connected')
    send('Connection established.')

@socketio.on('disconnect')
def handle_disconnect():
    print('Client disconnected')

if __name__ == '__main__':
    socketio.run(app, debug=True)
