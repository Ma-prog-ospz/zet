import { useEffect, useRef, useState } from "react";
import * as maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";

function getUrl(schema: string, secureSchema: string, path: string) {
  return window.location.protocol === "https:"
    ? `${secureSchema}://${window.location.host}/${path}`
    : `${schema}://${window.location.hostname}:5000/${path}`;
}

export function Map() {
  const mapContainer = useRef(null);
  const mapRef = useRef(null);

  useEffect(() => {
    if (!mapContainer.current) {
      return;
    }

    const map = new maplibregl.Map({
      container: mapContainer.current,
      style: '/style.json', // Fetch style from backend
      center: [15.9819, 45.815],
      zoom: 12,
    });

    map.on('load', () => {
      console.log('Map loaded');
    });

    return () => {
      map.remove();
    };
  }, []);

  return <div ref={mapContainer} style={{ width: "100%", height: "100%" }} />;
}
